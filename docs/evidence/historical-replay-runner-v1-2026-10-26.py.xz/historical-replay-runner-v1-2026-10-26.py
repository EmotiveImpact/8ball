"""Masked historical forecast replay (retrospective diagnostic, not validation).

Two separate steps. ``forecast`` sends only the pre-cutoff masked case to the
configured provider and freezes a typed Forecast. ``resolve`` later binds the
known outcome to that frozen forecast digest and scores it. The model never
receives the outcome file. A renamed historical story does not prevent model
memorisation; one case cannot establish predictive accuracy. Nothing here
creates evidence, approval, route selection or external action.
"""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from eightball.v2.compatible import CompatibleSession, settings  # noqa: E402
from endstate.forecasting import Forecast, Resolution, evaluate, forecast_digest  # noqa: E402

VERSION = 'historical-replay.v1'
PROMPT_VERSION = 'historical-forecast.v1'
SCHEMA = {
    'type': 'object', 'additionalProperties': False,
    'required': ['probability', 'abstention_reason', 'assumptions',
                 'most_informative_observation', 'recognises_real_case', 'recognition_note'],
    'properties': {
        'probability': {'type': ['number', 'null'], 'minimum': 0, 'maximum': 1},
        'abstention_reason': {'type': ['string', 'null'], 'maxLength': 1500},
        'assumptions': {'type': 'array', 'maxItems': 8, 'items': {'type': 'string', 'maxLength': 400}},
        'most_informative_observation': {'type': 'string', 'maxLength': 600},
        'recognises_real_case': {'type': 'boolean'},
        'recognition_note': {'type': 'string', 'maxLength': 600},
    },
}
INSTRUCTIONS = (
    'You are an advisory forecaster inside a decision-review tool. Use only the supplied case, '
    'as of its information cutoff. Give either a probability (0-1) that the stated event occurs by '
    'the horizon, or null with an explicit abstention_reason. Never give both. List the assumptions '
    'your number depends on and the single observation that would most change it. Report honestly '
    'whether you believe you recognise the specific real transaction; if so, still answer only from '
    'the supplied information. Your output is advice for human review, not evidence or a decision.'
)


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def digest(value) -> str:
    return sha256(canonical(value)).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def now():
    return datetime.now(timezone.utc)


def forecast(case_path, output, *, allow_external):
    case = load(case_path)
    if case['version'] != 'endstate.historical-replay.v1':
        raise ValueError('Unsupported case version')
    text = json.dumps(case['context'], ensure_ascii=False)
    for banned in ('validly terminated', 'chancery', 'court', 'settle', 'lawsuit', 'rent-a', 'vintage', 'riley', '126.5', '92.5'):
        if banned.lower() in text.lower():
            raise ValueError('Model-facing context contains post-cutoff or identifying text: ' + banned)
    context = {'as_of': case['as_of'], 'horizon': case['horizon'], 'event': case['event'],
               'case': case['context']}
    configured = settings()
    session = CompatibleSession(allow_external=allow_external)
    started = now()
    report = {'version': VERSION, 'prompt_version': PROMPT_VERSION, 'case_id': case['id'],
              'case_sha256': digest(case), 'input_sha256': digest(context),
              'schema_sha256': digest(SCHEMA), 'kind': case['kind'], 'masking': case['masking'],
              'provider': session.receipt, 'requested_at': started.isoformat(),
              'status': 'started', 'actual_model_inference': True,
              'outcome_supplied_to_model': False, 'forecast': None}
    try:
        answer, served = session.generate(SCHEMA, INSTRUCTIONS, context)
        report['served_model'] = served
        report['answer'] = answer
        prob = answer.get('probability')
        reason = answer.get('abstention_reason')
        if prob is not None:
            prob = float(prob)
        record = Forecast(id=case['id'], event=case['event'], as_of=case['as_of'],
                          horizon=case['horizon'], input_sha256=report['input_sha256'],
                          predictor=f"{configured.provider}:{served}:{PROMPT_VERSION}",
                          probability=prob, abstention_reason=reason)
        report['forecast'] = record.model_dump(mode='json')
        report['forecast_sha256'] = forecast_digest(record)
        report['status'] = 'forecast_frozen'
    except Exception as exc:  # retained, never retried
        report['status'] = 'failed'
        report['error'] = type(exc).__name__ + ': ' + str(exc)[:500]
    finally:
        report['completed_at'] = now().isoformat()
        report['receipt'] = session.receipt
        report['notice'] = ('Retrospective replay recorded after the real outcome existed. The forecast '
                            'as_of is the information cutoff, not when this request was made. Recognition '
                            'of the masked case or memorised history cannot be excluded.')
        out = Path(output) / (started.strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8])
        out.mkdir(parents=True, exist_ok=False)
        (out / 'forecast-report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
        print(out / 'forecast-report.json')
    return report


def resolve(report_path, outcome_path, sources_path):
    report = load(report_path)
    outcome = load(outcome_path)
    sources = load(sources_path)
    if report.get('status') != 'forecast_frozen':
        raise ValueError('Only a frozen forecast can be resolved')
    if outcome['case_id'] != report['case_id']:
        raise ValueError('Outcome refers to a different case')
    record = Forecast.model_validate(report['forecast'])
    if forecast_digest(record) != report['forecast_sha256']:
        raise ValueError('Forecast report digest mismatch')
    bundle = {'outcome_sha256': digest(outcome), 'retrieved_sources': sources}
    resolution = Resolution(forecast_id=record.id, forecast_sha256=report['forecast_sha256'],
                            value=outcome['value'], available_at=outcome['available_at'],
                            source_reference=outcome['summary'], source_sha256=digest(bundle),
                            basis='observed')
    result = evaluate([record], [resolution], as_of=now())
    scored = {'version': VERSION, 'forecast_report': str(report_path),
              'forecast_sha256': report['forecast_sha256'], 'resolution': resolution.model_dump(mode='json'),
              'resolution_bundle': bundle, 'evaluation': result,
              'retrospective': True, 'held_out_validation': False, 'cases': 1,
              'predictive_quality_approved': False,
              'notice': 'One retrospective masked case. Hindsight contamination, model recognition and '
                        'sample size of one prevent any accuracy claim. Scores are diagnostic only.'}
    path = Path(report_path).with_name('resolution-report.json')
    path.write_text(json.dumps(scored, indent=2, ensure_ascii=False) + '\n')
    print(path)
    return scored


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    f = sub.add_parser('forecast')
    f.add_argument('--case', required=True)
    f.add_argument('--output', required=True)
    f.add_argument('--allow-external', action='store_true')
    r = sub.add_parser('resolve')
    r.add_argument('--report', required=True)
    r.add_argument('--outcome', required=True)
    r.add_argument('--sources', required=True)
    args = parser.parse_args(argv)
    if args.command == 'forecast':
        return 0 if forecast(args.case, args.output, allow_external=args.allow_external)['status'] == 'forecast_frozen' else 1
    resolve(args.report, args.outcome, args.sources)
    return 0


if __name__ == '__main__':
    sys.exit(main())
